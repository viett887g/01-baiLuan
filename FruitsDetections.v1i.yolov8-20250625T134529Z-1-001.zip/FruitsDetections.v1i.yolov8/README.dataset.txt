# TGMT final > 2024-12-14 10:21pm
https://universe.roboflow.com/bietto/tgmt-final

Provided by a Roboflow user
License: CC BY 4.0

